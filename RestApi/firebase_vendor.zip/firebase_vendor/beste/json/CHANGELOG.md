# CHANGELOG

## Unreleased

## [1.0.0] - 2022-02-12

Initial release

[Unreleased]: https://github.com/beste/json/compare/1.0.1...main
[1.0.0]: https://github.com/beste/json/releases/tag/1.0.0

