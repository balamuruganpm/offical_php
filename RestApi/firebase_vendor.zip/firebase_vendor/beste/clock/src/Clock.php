<?php

declare(strict_types=1);

namespace Beste;

use StellaMaris\Clock\ClockInterface;

interface Clock extends ClockInterface
{

}
