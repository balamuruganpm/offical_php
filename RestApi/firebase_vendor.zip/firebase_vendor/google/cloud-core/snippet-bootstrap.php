<?php

use Google\Cloud\Core\Testing\TestHelpers;

TestHelpers::snippetBootstrap();

date_default_timezone_set('UTC');
